export const environment = {
  production: true,
  api: 'https://api.themoviedb.org/3'
};
