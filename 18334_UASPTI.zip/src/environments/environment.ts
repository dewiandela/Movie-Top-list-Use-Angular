export const environment = {
  production: false,
  api: 'https://api.themoviedb.org/3'
};